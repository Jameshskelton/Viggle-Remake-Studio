import { NextResponse } from "next/server";
import { clearClipCache } from "../../../../lib/storage.ts";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST() {
  try {
    return NextResponse.json(await clearClipCache());
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Unable to clear the clip cache." },
      { status: 500 },
    );
  }
}
