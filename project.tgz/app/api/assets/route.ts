import { NextResponse } from "next/server";
import { saveAsset } from "../../../lib/assets.ts";
import type { AssetKind } from "../../../lib/types.ts";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_BYTES = 512 * 1024 * 1024;

export async function POST(request: Request) {
  try {
    const form = await request.formData();
    const file = form.get("file");
    const kind = String(form.get("kind") ?? "") as AssetKind;
    if (!(file instanceof File)) return NextResponse.json({ error: "Choose a file to upload." }, { status: 400 });
    if (kind !== "video" && kind !== "image") return NextResponse.json({ error: "Unknown asset kind." }, { status: 400 });
    if (file.size === 0) return NextResponse.json({ error: "That file is empty." }, { status: 400 });
    if (file.size > MAX_BYTES) return NextResponse.json({ error: "Files are limited to 512 MB." }, { status: 413 });
    const videoExt = /\.(mp4|mov|mkv|webm|avi)$/i.test(file.name);
    const imageExt = /\.(png|jpe?g|webp|gif)$/i.test(file.name);
    if (kind === "video" && !file.type.startsWith("video/") && !videoExt) {
      return NextResponse.json({ error: "The source must be a video." }, { status: 400 });
    }
    if (kind === "image" && !file.type.startsWith("image/") && !imageExt) {
      return NextResponse.json({ error: "The character must be an image." }, { status: 400 });
    }
    const type = file.type || (kind === "video" ? "video/mp4" : "image/png");
    const asset = await saveAsset(new Uint8Array(await file.arrayBuffer()), file.name || "upload", type, kind);
    return NextResponse.json({ asset, url: `/api/assets/${asset.id}/file` });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Unable to save that file." }, { status: 400 });
  }
}
