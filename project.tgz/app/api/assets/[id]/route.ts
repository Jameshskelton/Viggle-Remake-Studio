import { NextResponse } from "next/server";
import { getAsset } from "../../../../lib/assets.ts";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const asset = await getAsset(id);
  if (!asset) return NextResponse.json({ error: "Asset not found." }, { status: 404 });
  return NextResponse.json({ asset, url: `/api/assets/${asset.id}/file` });
}
