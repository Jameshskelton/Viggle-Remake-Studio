import { createReadStream } from "node:fs";
import { stat } from "node:fs/promises";
import { Readable } from "node:stream";
import { NextResponse } from "next/server";
import { assetFile, getAsset } from "../../../../../lib/assets.ts";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const TYPES: Record<string, string> = {
  mp4: "video/mp4", mov: "video/quicktime", webm: "video/webm", mkv: "video/x-matroska",
  png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", webp: "image/webp", gif: "image/gif",
};

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const asset = await getAsset(id);
  if (!asset) return NextResponse.json({ error: "Asset not found." }, { status: 404 });
  const file = assetFile(asset);
  let size: number;
  try {
    size = (await stat(file)).size;
  } catch {
    return NextResponse.json({ error: "Asset file is missing." }, { status: 404 });
  }
  const ext = file.split(".").pop()?.toLowerCase() ?? "";
  const type = TYPES[ext] ?? asset.mime ?? "application/octet-stream";
  const range = request.headers.get("Range");
  const headers = new Headers({ "Content-Type": type, "Accept-Ranges": "bytes", "Cache-Control": "private, max-age=3600" });
  if (new URL(request.url).searchParams.has("download")) {
    const name = asset.name.replace(/[^\w.-]+/g, "_") || `asset.${ext || "bin"}`;
    headers.set("Content-Disposition", `attachment; filename="${name}"`);
  }
  if (!range) {
    headers.set("Content-Length", String(size));
    return new Response(Readable.toWeb(createReadStream(file)) as ReadableStream, { headers });
  }
  const match = range.match(/bytes=(\d*)-(\d*)/);
  if (!match) return new Response(null, { status: 416, headers: { "Content-Range": `bytes */${size}` } });
  let start: number;
  let end: number;
  if (match[1] === "") {
    const suffix = Number(match[2]);
    if (!Number.isFinite(suffix) || suffix <= 0) {
      return new Response(null, { status: 416, headers: { "Content-Range": `bytes */${size}` } });
    }
    start = Math.max(0, size - suffix);
    end = size - 1;
  } else {
    start = Number(match[1]);
    end = match[2] ? Math.min(Number(match[2]), size - 1) : size - 1;
  }
  if (start > end || start >= size) return new Response(null, { status: 416, headers: { "Content-Range": `bytes */${size}` } });
  headers.set("Content-Range", `bytes ${start}-${end}/${size}`);
  headers.set("Content-Length", String(end - start + 1));
  return new Response(Readable.toWeb(createReadStream(file, { start, end })) as ReadableStream, { status: 206, headers });
}
