import { NextResponse } from "next/server";
import { deleteStoredRenders } from "../../../../lib/render-store.ts";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({})) as {
      ids?: unknown;
      mode?: unknown;
      all?: unknown;
      keepAssetIds?: unknown;
    };
    const ids = Array.isArray(body.ids)
      ? body.ids.filter((id): id is string => typeof id === "string" && /^[a-f0-9-]{36}$/i.test(id))
      : [];
    const mode = body.mode === "swap" || body.mode === "edit" ? body.mode : undefined;
    const all = body.all === true;
    if (!ids.length && !mode && !all) {
      return NextResponse.json({ error: "Choose the renders to delete." }, { status: 400 });
    }
    const keepAssetIds = Array.isArray(body.keepAssetIds)
      ? body.keepAssetIds.filter((id): id is string => typeof id === "string" && /^[a-f0-9-]{36}$/i.test(id))
      : [];
    const result = await deleteStoredRenders({
      ids: ids.length ? ids : undefined,
      mode,
      all,
      keepAssetIds,
    });
    return NextResponse.json(result);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Unable to delete the stored renders." },
      { status: 500 },
    );
  }
}
