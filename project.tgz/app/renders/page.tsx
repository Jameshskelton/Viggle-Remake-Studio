import { Renders } from "../../components/renders.tsx";

export default function RendersPage() {
  return <Renders />;
}
